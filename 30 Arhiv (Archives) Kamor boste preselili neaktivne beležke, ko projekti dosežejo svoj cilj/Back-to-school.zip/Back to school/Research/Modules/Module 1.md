---
Class: Module
Priority: 
Assessments: ["[[Assessment 1]]", "[[Assessment 2]]"]
Teachers: 
Active: true
---

[writing a note](https://youtu.be/dBnlKd1eXl8?t=177)

