---
Class: Assessment
Date: 
Module: "[[Module 1]]"
Deadline: 2023-09-14
---
- [ ] Write something for this
- [ ] do this other thing

