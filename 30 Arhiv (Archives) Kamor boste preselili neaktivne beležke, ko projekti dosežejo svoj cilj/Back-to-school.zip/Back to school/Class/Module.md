---
limit: 100
mapWithTag: false
icon: boxes
tagNames: 
excludes: 
extends: 
version: 5
---
Class:: {"type":"Select","options":{"valuesList":{},"sourceType":"ValuesFromDVQuery","valuesListNotePath":"","valuesFromDVQuery":"dv.pages('\"Class\"').map(p => p.file.name)"}}
Assessments:: {"type":"MultiFile","options":{"dvQueryString":"dv.pages('\"Research/Assessments\"')"}}
Teachers:: {"type":"Input","options":{}}
Active:: {"type":"Boolean","options":{}}