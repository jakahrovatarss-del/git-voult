---
limit: 100
mapWithTag: false
icon: help
tagNames: 
excludes: 
extends: 
version: 1
---
Class:: {"type":"Select","options":{"valuesList":{},"sourceType":"ValuesFromDVQuery","valuesListNotePath":"","valuesFromDVQuery":"dv.pages('\"Class\"').map(p => p.file.name)"}}