---
limit: 100
mapWithTag: false
icon: file-input
tagNames: 
excludes: 
extends: 
version: 4
---
Class:: {"type":"Select","options":{"valuesList":{},"sourceType":"ValuesFromDVQuery","valuesListNotePath":"","valuesFromDVQuery":"dv.pages('\"Class\"').map(p => p.file.name)"}}
URL:: {"type":"Input","options":{}}