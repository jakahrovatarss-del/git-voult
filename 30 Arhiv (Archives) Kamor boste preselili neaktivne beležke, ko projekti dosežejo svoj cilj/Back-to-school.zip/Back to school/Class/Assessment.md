---
limit: 100
mapWithTag: false
icon: shield-check
tagNames: 
excludes: 
extends: Default
version: 5
---
Class:: {"type":"Select","options":{"valuesList":{},"sourceType":"ValuesFromDVQuery","valuesListNotePath":"","valuesFromDVQuery":"dv.pages('\"Class\"').map(p => p.file.name)"}}
Date:: {"type":"Date","options":{"dateFormat":"YYYY-MM-DD","defaultInsertAsLink":"false"}}
Deadline:: {"type":"Date","options":{"dateFormat":"YYYY-MM-DD","defaultInsertAsLink":"false"}}
Module:: {"type":"File","options":{"dvQueryString":"dv.pages('\"Research/Modules\"')"}}