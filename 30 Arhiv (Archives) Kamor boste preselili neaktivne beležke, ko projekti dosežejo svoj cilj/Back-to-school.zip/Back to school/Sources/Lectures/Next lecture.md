---
Class: Lecture
Date: 2023-09-30
Priority: 
Module: 
Status: To attend
---
