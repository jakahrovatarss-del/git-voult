---
Class: Lecture
Date: 2023-09-05
Priority: 
Module: "[[Module 1]]"
---
