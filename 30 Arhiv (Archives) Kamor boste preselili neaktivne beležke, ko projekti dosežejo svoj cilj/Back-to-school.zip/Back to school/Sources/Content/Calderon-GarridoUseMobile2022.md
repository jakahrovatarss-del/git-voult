---
Class: Source
---

Title:: The Use of Mobile Phones in Classrooms: A Systematic Review
URL: https://online-journals.org/index.php/i-jet/article/view/29181
Zotero Link: [PDF The Use of Mobile Phones in Classrooms - A Systematic Review.pdf](zotero://select/library/items/HXPA4LPI)
Author: Diego Calderón-Garrido, Francisco Javier Ramos-Pardo, Cristóbal Suárez-Guerrero
Year:  2022

a total of 60 articles indexed to theJournal Citation Reports data base between the years 2011 and 2020 have been analysed.” Yellow Highlight [Page 1](zotero://open-pdf/library/items/HXPA4LPI?page=1&annotation=S68MIHTR) 
 
![[Images/Calderon-GarridoUseMobile2022/image-3-x125-y283.png]] 
 
the variables of gender and age significantly affected nomophobic conduct, while experience using mobile phones and accessibility did not affect this.” Yellow Highlight [Page 10](zotero://open-pdf/library/items/HXPA4LPI?page=10&annotation=JVX78UW8) 
 
results confirmed that student gender was related to self-esteem.” Yellow Highlight [Page 10](zotero://open-pdf/library/items/HXPA4LPI?page=10&annotation=IR8M7JBN) 
 
results showed how emotional intelligence significantly reduced nomophobia.” Yellow Highlight [Page 10](zotero://open-pdf/library/items/HXPA4LPI?page=10&annotation=UJ2A9C77) 
 
unconscious loss of control was detected caused by this dependence.” Yellow Highlight [Page 10](zotero://open-pdf/library/items/HXPA4LPI?page=10&annotation=R7RXIAXF) 
 
more pronounced in the case of girls.” Yellow Highlight [Page 10](zotero://open-pdf/library/items/HXPA4LPI?page=10&annotation=JDS3GIIE) 
 
age did not influence this loss of control.” Yellow Highlight [Page 10](zotero://open-pdf/library/items/HXPA4LPI?page=10&annotation=RDGAHDM4) 
 
results showed that this addiction is greater in the case of women than of men.” Yellow Highlight [Page 10](zotero://open-pdf/library/items/HXPA4LPI?page=10&annotation=CNDHT3QC) 
 
effect on performance was more pronounced in the case of men, w” Yellow Highlight [Page 10](zotero://open-pdf/library/items/HXPA4LPI?page=10&annotation=UVNAZJBH) 
 
high level of addiction that was related to a lack of well-beingin the classroom and which, in turn, negatively affected cooperative learning” Yellow Highlight [Page 10](zotero://open-pdf/library/items/HXPA4LPI?page=10&annotation=J8QIWIQ8) 
 
those students that used their mobile phones for fewer hours had more parent-child communication” Yellow Highlight [Page 10](zotero://open-pdf/library/items/HXPA4LPI?page=10&annotation=EKQ8G73P) 
 
use of mobil e phones is quite usual in language teaching, through specific applications and others that are commonly used, even allowing work with sophisticated texts.” Yellow Highlight [Page 12](zotero://open-pdf/library/items/HXPA4LPI?page=12&annotation=2HXTXQ92) 
 
use has been observed include formative evaluations to boost cooperativelearning and teacher training” Yellow Highlight [Page 12](zotero://open-pdf/library/items/HXPA4LPI?page=12&annotation=3432XK8M) 
 
use of mobile phones in classrooms often leads to tension between teachers and pupils” Yellow Highlight [Page 12](zotero://open-pdf/library/items/HXPA4LPI?page=12&annotation=NJDT3VVW) 
 
Restrictive policies lead to a dynamic of invigilating-cheating-punishment and also diminishes any educational use or initiative when the parties are in agreement.” Yellow Highlight [Page 12](zotero://open-pdf/library/items/HXPA4LPI?page=12&annotation=TNSBTZPQ) 
 
some studies point out that their use negatively affects performance, although there are others that highlight the contribution of mobile phones to overcoming deficiencies in education systems in some countries, thus improving performance” Yellow Highlight [Page 12](zotero://open-pdf/library/items/HXPA4LPI?page=12&annotation=KZ25U6JE) 
 
The most commonly studied problems, like nomophobia and loss of control and dependency can be avoided if there is sufficient emotional education and good development of media literacy.” Yellow Highlight [Page 12](zotero://open-pdf/library/items/HXPA4LPI?page=12&annotation=TEH3Z7DN) 
 
imposition and an authoritarian disciplinary style are negatively related to the problem of dependency” Yellow Highlight [Page 12](zotero://open-pdf/library/items/HXPA4LPI?page=12&annotation=A3DHDHEJ) 
 
he most present and most concerning problem is cyber-bullying although, despite this, the lack of prevention is striking.” Yellow Highlight [Page 12](zotero://open-pdf/library/items/HXPA4LPI?page=12&annotation=5RNHN5QY) 
 
scientific production would seem to back the benefits of introducing mobile phones into classrooms for educational purposes provided that preliminary work is done and a certain development of digital and media skills is achieved in both pupils and teachers.” Yellow Highlight [Page 12](zotero://open-pdf/library/items/HXPA4LPI?page=12&annotation=YSXGFLUP) 
 


%% Import Date: 2023-09-11T15:03:26.036+01:00 %%
